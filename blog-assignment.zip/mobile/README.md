# Mobile (Flutter + GetX)

Quickstart:
1. Install Flutter SDK
2. cd mobile
3. flutter pub get
4. flutter run

This is a minimal skeleton. Implement API calls in controllers using `http` and manage state with GetX.
