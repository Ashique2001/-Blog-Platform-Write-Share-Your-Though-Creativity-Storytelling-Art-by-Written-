# Blog Assignment Starter (Backend + Frontend + Mobile)

This repository contains a starter scaffold for the blog assignment:

- backend/  - Node.js + Express + MongoDB (auth, posts, profile)
- frontend/ - React + Redux Toolkit + SCSS (minimal pages)
- mobile/   - Flutter + GetX skeleton

Follow each subfolder README for setup instructions.

Good luck! — Generated for you by ChatGPT
