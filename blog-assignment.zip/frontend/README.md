# Frontend (React + Redux Toolkit + SCSS)

Quickstart:
1. cd frontend
2. npm install
3. npm start

This is a minimal starter with:
- auth slice, posts slice
- pages: Home, Login, Signup, PostDetail, CreatePost, Profile
- configure API base URL in src/api/config.js
