# Backend (Node.js + Express)

## Quickstart
1. cd backend
2. npm install
3. copy `.env.example` to `.env` and set MONGO_URI, JWT_SECRET
4. npm run dev

API endpoints:
- POST /api/auth/signup
- POST /api/auth/login
- GET/POST /api/posts
- GET/PUT/DELETE /api/posts/:id
- GET /api/profile/:id
